function x = mychi2inv(p, df)
    % 自定义卡方分布逆累积分布函数，替代MATLAB chi2inv（无Statistics工具箱依赖）
    % 输入：
    %   p - 累积概率，0 < p < 1（如0.95对应95%置信水平）
    %   df - 卡方分布自由度，正整数（原代码中df=1）
    % 输出：
    %   x - 临界值，满足P(χ²(df) ≤ x) = p
    % 核心：卡方CDF（基于下不完全伽马函数） + 二分法求逆，纯基础代码实现
    % 适配原代码：mychi2inv(0.95,1) = 3.8415（与原chi2inv结果一致，精度1e-8）
    
    %% 输入校验（避免无效参数）
    if nargin ~= 2
        error('输入参数必须为2个：mychi2inv(累积概率p, 自由度df)');
    end
    if p <= 0 || p >= 1
        error('累积概率p必须满足：0 < p < 1');
    end
    if ~isscalar(df) || fix(df) ~= df || df < 1
        error('自由度df必须为正整数');
    end
    
    %% 二分法初始化：确定搜索区间[x_low, x_high]
    x_low = 0;          % 卡方分布取值下界为0
    x_high = 1;         % 初始上界，逐步扩大直到CDF(x_high) >= p
    while chi2_cdf(x_high, df) < p
        x_high = x_high * 2; % 上界翻倍，直到满足条件
    end
    
    %% 二分法求根：收敛阈值1e-8（兼顾精度和速度，可按需调整）
    tol = 1e-8;
    iter = 0;
    max_iter = 100;     % 最大迭代次数，防止死循环
    while (x_high - x_low) > tol && iter < max_iter
        iter = iter + 1;
        x_mid = (x_low + x_high) / 2;
        cdf_mid = chi2_cdf(x_mid, df);
        if cdf_mid < p
            x_low = x_mid;  % 累积概率不足，向右搜索
        else
            x_high = x_mid; % 累积概率超了，向左搜索
        end
    end
    
    %% 输出临界值（取区间中点，保证精度）
    x = (x_low + x_high) / 2;

    %% 内嵌函数1：卡方分布累积分布函数（CDF）
    function F = chi2_cdf(x, df)
        if x <= 0
            F = 0;
            return;
        end
        % 卡方分布CDF公式：F(x) = Γ(df/2, x/2) / Γ(df/2)
        % Γ(·,·)：下不完全伽马函数；Γ(·)：伽马函数（MATLAB基础版自带gamma）
        a = df / 2;
        z = x / 2;
        F = my_gammainc_lower(a, z) / gamma(a);
    end

    %% 内嵌函数2：下不完全伽马函数 Γ(a,z) 级数展开近似（核心！无工具箱依赖）
    function g = my_gammainc_lower(a, z)
        % 级数展开公式：Γ(a,z) = z^a * exp(-z) * Σ(n=0→∞) z^n / [a(a+1)...(a+n)]
        % 收敛条件：z > 0, a > 0（卡方分布场景完全满足）
        if z == 0
            g = 0;
            return;
        end
        term = z^a * exp(-z) / a; % 第0项
        g = term;
        n = 0;
        while term > 1e-10 * g % 余项小于1e-10时停止，保证精度
            n = n + 1;
            term = term * z / (a + n); % 递推计算后续项
            g = g + term;
        end
    end

end