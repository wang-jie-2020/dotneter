function options = optimoptions(optimizer, varargin)
    % 自定义优化选项配置函数，替代MATLAB optimoptions（无Optimization工具箱依赖）
    % 调用格式与原函数完全一致，适配所有常见优化选项：
    % 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm', 'interior-point')
    % 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX', 1e-8)
    % 输入：
    %   optimizer - 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际限制）
    %   varargin  - 可变参数，必须为「选项名-选项值」成对的字符+值组合
    % 输出：
    %   options   - 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应配置
    % 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon完美适配
    
    %% 输入合法性校验
    % 校验优化器名称是否为字符型
    if ~ischar(optimizer)
        error('第一个参数必须为优化器名称（字符型），如''fmincon''');
    end
    % 校验可变参数是否为成对的「选项名-选项值」（数量必须为偶数）
    if mod(length(varargin), 2) ~= 0
        error('可变参数必须为「选项名-选项值」成对输入，如''Display'', ''off''');
    end
    
    %% 初始化选项结构体
    options = struct();
    % 标记优化器名称（兼容原函数，myfmincon可忽略该字段）
    options.Optimizer = optimizer;
    
    %% 遍历可变参数，将「选项名-选项值」写入结构体
    for i = 1:2:length(varargin)
        opt_name = varargin{i};    % 选项名（如'Display'）
        opt_val  = varargin{i+1};  % 选项值（如'off'/'iter'/1000）
        % 校验选项名是否为字符型
        if ~ischar(opt_name)
            error(['第', num2str(i+1), '个参数必须为选项名（字符型），如''Display''']);
        end
        % 将选项名作为结构体字段，赋值对应选项值（直接保留原名称，不修改大小写）
        options.(opt_name) = opt_val;
    end

end