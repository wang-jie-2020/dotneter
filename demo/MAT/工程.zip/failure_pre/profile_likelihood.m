function [F_CI] = profile_likelihood(t, normal_data, failure_data, alpha, F_range)
    % 使用Profile似然法计算累积失效率F(t)的置信区间
    % 输入:
    %   t - 时间点
    %   data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    %   alpha - 显著性水平 (默认0.05)
    %   F_range - F值的搜索范围 (可选)
    % 输出:
    %   F_CI - 置信区间 [下限, 上限]
    %   F_profile - 用于绘图的F值数组
    %   LR_stat - 似然比统计量数组
    
    if nargin < 4
        alpha = 0.05;
    end
    
    % 卡方分布临界值
    chi2_crit = mychi2inv(1 - alpha, 1);
    
    %% 步骤1: 无约束最大似然估计
    [beta_hat, eta_hat, max_loglik] = unconstrained_mle(normal_data, failure_data);
    F_hat = 1 - exp(-(t/eta_hat)^beta_hat);
    
    %% 步骤2: 确定F的搜索范围
    if nargin < 5 || isempty(F_range)
        % 自动确定搜索范围
        F_min = max(1e-6, F_hat - 0.2);
        F_max = min(0.999, F_hat + 0.2);
        F_profile = linspace(F_min, F_max, 10000);
    else
        F_profile = F_range;
    end
    
    %% 步骤3: 计算每个F值约束下的profile似然
    n_points = length(F_profile);
    profile_loglik = zeros(n_points, 1);
    beta_profile = zeros(n_points, 1);
    eta_profile = zeros(n_points, 1);
    
    for i = 1:n_points
        F0 = F_profile(i);
        
        % 在约束 F(t) = F0 下优化参数
        [beta_opt, eta_opt, loglik_opt] = constrained_mle(F0, t, normal_data, failure_data, beta_hat, eta_hat);
        
        beta_profile(i) = beta_opt;
        eta_profile(i) = eta_opt;
        profile_loglik(i) = loglik_opt;
    end
    
    %% 步骤4: 计算似然比统计量
    LR_stat = 2 * (max_loglik - profile_loglik);
    
    %% 步骤5: 找到置信区间边界
    % 找到LR统计量 <= 临界值的F值
    in_ci = (LR_stat <= chi2_crit);
    
    if sum(in_ci) < 2
        warning('Profile似然置信区间可能不准确，考虑扩大搜索范围');
        F_CI = [NaN, NaN];
    else
        F_CI = [min(F_profile(in_ci)), max(F_profile(in_ci))];
    end
    
end
