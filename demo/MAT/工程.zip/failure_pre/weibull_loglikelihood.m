function logL = weibull_loglikelihood(params,normal_data,failure_data)
% 构建威布尔分布似然函数（处理区间删失数据）
% parrms = [beta,eta]形状参数和尺度参数
beta = params(1);
eta = params(2);

if beta<=0||eta<=0
    logL = -1e10;%惩罚无效参数
    return;
end

logL = 0;

%处理正常pack（右删失数据）
%似然贡献：R(t) = 1-F(t) = exp(-(t/eta)^beta)
for i = 1:size(normal_data,1)
    t = normal_data(i,1);
    count = normal_data(i,2);
    reliability = exp(-(t/eta)^beta);
    logL = logL+count*log(reliability);
end

%处理失效pack（区间删失数据）
%似然贡献：F(t_upper)-F(t_lower)
for i = 1:size(failure_data,1)
    t_lower = failure_data(i,1);
    t_upper = failure_data(i,2);
    count = failure_data(i,3);

    if t_lower == t_upper%确切失效时间
        %使用概率密度函数f(t)=(beta/eta)*(t/eta)^(beta-1)*exp(-(t/eta)^beta)
        if t_lower>0
            pdf_value = (beta/eta)*(t_lower/eta)^(beta-1)*exp(-(t_lower/eta)^beta);
            logL = logL+count*log(pdf_value);
        else
            logL = logL-1e6;%惩罚无效时间
        end
    else %区间失效时间
        F_lower = 1-exp(-(t_lower/eta)^beta);
        F_upper = 1-exp(-(t_upper/eta)^beta);
        interval_prob = F_upper-F_lower;

        if interval_prob>0
            logL = logL+count*log(interval_prob);
        else
            logL = logL-1e6; %惩罚无效概率
        end
    end
end
end



