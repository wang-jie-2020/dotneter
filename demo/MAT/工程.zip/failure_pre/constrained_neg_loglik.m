function nll = constrained_neg_loglik(beta, F0, t, normal_data, failure_data)
    % 约束下的负对数似然函数
    
    % 根据约束计算eta
    if F0 >= 1 || F0 <= 0
        nll = 1e10;
        return;
    end
    
    eta = t / (-log(1-F0))^(1/beta);
    
    if eta <= 0 || ~isfinite(eta)
        nll = 1e10;
        return;
    end
    
    % 计算对数似然
    loglik = weibull_loglikelihood([beta, eta], normal_data, failure_data);
    nll = -loglik;
end
