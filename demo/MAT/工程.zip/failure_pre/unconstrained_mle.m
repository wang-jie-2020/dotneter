function [beta_hat, eta_hat, max_loglik] = unconstrained_mle(normal_data, failure_data)
    % 无约束威布尔分布参数最大似然估计
    
    % 初始猜测
    initial_beta = 1.5;
    initial_eta = 5000;
    
    % 负对数似然函数
    neg_loglik = @(params) -weibull_loglikelihood(params, normal_data, failure_data);
    
    % 约束优化
    lb = [0.1, 1];
    ub = [10, 1e7];
    
    options = optimoptions('fmincon', 'Display', 'off', 'Algorithm', 'interior-point');
    [params_opt, nll_value] = myfmincon(neg_loglik, [initial_beta, initial_eta], [], [], [], [], lb, ub, [], options);
    
    beta_hat = params_opt(1);
    eta_hat = params_opt(2);
    max_loglik = -nll_value;
end
