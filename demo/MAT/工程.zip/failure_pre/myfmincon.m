function [x_opt, fval_opt, exitflag] = myfmincon(obj_fun, x0, A, b, Aeq, beq, lb, ub, nonlcon, options)
    % 自定义约束优化函数：替代MATLAB fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/beq/nonlcon暂置空）
    % 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,x0,[],[],[],[],lb,ub,[],options)
    % 核心算法：Nelder-Mead单纯形法 + 约束投影（超出lb/ub的点强制拉回约束区间）
    % 适用场景：仅上下界约束的标量目标函数最小化（完美适配原代码负对数似然函数最小化）
    % 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标志（1=收敛，0=达到最大迭代，-1=失败）
    
    %% 1. 参数初始化：解析输入+设置默认值（兼容原fmincon的options）
    % 处理无约束参数（原代码未用A/b/Aeq/beq/nonlcon，直接置空）
    if nargin < 3 || isempty(A), A = []; end
    if nargin < 4 || isempty(b), b = []; end
    if nargin < 5 || isempty(Aeq), Aeq = []; end
    if nargin < 6 || isempty(beq), beq = []; end
    if nargin < 9 || isempty(nonlcon), nonlcon = []; end
    % 上下界默认值：无下界/无上界（原代码会传入lb/ub，此处为兼容）
    if nargin <7 || isempty(lb), lb = -inf(size(x0)); end
    if nargin <8 || isempty(ub), ub = inf(size(x0)); end
    % 优化选项默认值（与原代码optimset匹配，可通过options修改）
    disp_iter = 'off'; MaxIter = 500; TolX = 1e-8; TolFun = 1e-8;
    if nargin >=10 && ~isempty(options)
        if isfield(options, 'Display'), disp_iter = options.Display; end
        if isfield(options, 'MaxIter'), MaxIter = options.MaxIter; end
        if isfield(options, 'TolX'), TolX = options.TolX; end
        if isfield(options, 'TolFun'), TolFun = options.TolFun; end
    end
    n = length(x0); % 优化参数维度（原代码n=2，beta+eta）
    exitflag = 1;   % 收敛标志初始化
    iter = 0;       % 迭代次数
    
    %% 2. 初始化Nelder-Mead单纯形顶点（n维参数生成n+1个顶点，均在约束区间内）
    alpha = 1.0; beta = 0.5; gamma = 2.0; sigma = 0.5; % 单纯形法经典系数（反射/扩展/收缩/压缩）
    simplex = zeros(n+1, n); % 单纯形矩阵：每行一个顶点，共n+1行
    f_simplex = zeros(n+1, 1); % 每个顶点对应的目标函数值
    % 初始顶点1：输入的初始值x0（投影到约束区间）
    simplex(1,:) = project2constraint(x0, lb, ub);
    f_simplex(1) = feval(obj_fun, simplex(1,:));
    % 生成其余n个顶点（基于x0小幅扰动，保证在约束区间内）
    for i = 2:n+1
        v = x0;
        v(i-1) = v(i-1) * (1 + 0.05); % 对第i-1个参数小幅扰动（5%）
        simplex(i,:) = project2constraint(v, lb, ub);
        f_simplex(i) = feval(obj_fun, simplex(i,:));
    end
    
    %% 3. 迭代优化：Nelder-Mead核心逻辑 + 约束投影
    while iter < MaxIter
        iter = iter + 1;
        % 步骤1：对顶点按目标函数值升序排序（f最小为最优顶点，f最大为最劣顶点）
        [f_simplex, idx] = sort(f_simplex);
        simplex = simplex(idx, :);
        x_best = simplex(1,:); f_best = f_simplex(1); % 最优顶点
        x_worst = simplex(end,:); f_worst = f_simplex(end); % 最劣顶点
        x_centroid = mean(simplex(1:end-1,:), 1); % 除最劣顶点外的形心
        
        % 步骤2：收敛判断（参数变化量+函数值变化量均满足阈值）
        x_diff = max(max(abs(simplex - repmat(x_best, n+1, 1)))); % 参数最大偏差
        f_diff = max(abs(f_simplex - f_best)); % 函数值最大偏差
        if x_diff < TolX && f_diff < TolFun
            if strcmp(disp_iter, 'iter'), fprintf('迭代收敛：iter=%d, x_diff=%.4e, f_diff=%.4e\n', iter, x_diff, f_diff); end
            break;
        end
        
        % 步骤3：反射（Reflect）
        x_reflect = x_centroid + alpha * (x_centroid - x_worst);
        x_reflect = project2constraint(x_reflect, lb, ub); % 投影到约束区间
        f_reflect = feval(obj_fun, x_reflect);
        if f_reflect >= f_simplex(1) && f_reflect < f_simplex(end-1)
            % 反射点在最优和次劣之间，替换最劣顶点
            simplex(end,:) = x_reflect;
            f_simplex(end) = f_reflect;
            continue;
        end
        
        % 步骤4：扩展（Expand）：反射点优于最优顶点，继续扩展
        if f_reflect < f_simplex(1)
            x_expand = x_centroid + gamma * (x_reflect - x_centroid);
            x_expand = project2constraint(x_expand, lb, ub);
            f_expand = feval(obj_fun, x_expand);
            if f_expand < f_reflect
                simplex(end,:) = x_expand;
                f_simplex(end) = f_expand;
            else
                simplex(end,:) = x_reflect;
                f_simplex(end) = f_reflect;
            end
            continue;
        end
        
        % 步骤5：收缩（Contract）：反射点劣于次劣顶点，向内收缩
        x_contract = x_centroid + beta * (x_worst - x_centroid);
        x_contract = project2constraint(x_contract, lb, ub);
        f_contract = feval(obj_fun, x_contract);
        if f_contract < f_worst
            simplex(end,:) = x_contract;
            f_simplex(end) = f_contract;
            continue;
        end
        
        % 步骤6：压缩（Shrink）：收缩点仍劣，所有顶点向最优顶点压缩
        for i = 2:n+1
            simplex(i,:) = x_best + sigma * (simplex(i,:) - x_best);
            simplex(i,:) = project2constraint(simplex(i,:), lb, ub);
            f_simplex(i) = feval(obj_fun, simplex(i,:));
        end
        
        % 迭代显示（与原fmincon格式相似）
        if strcmp(disp_iter, 'iter')
            fprintf('iter=%d, 最优函数值=%.6e, 参数最大偏差=%.4e\n', iter, f_best, x_diff);
        end
    end
    
    %% 4. 迭代结束处理
    if iter >= MaxIter
        exitflag = 0; % 达到最大迭代次数
        if strcmp(disp_iter, 'iter'), fprintf('达到最大迭代次数：MaxIter=%d\n', MaxIter); end
    end
    % 输出最优结果
    [fval_opt, best_idx] = min(f_simplex);
    x_opt = simplex(best_idx, :);
end

%% 内嵌函数：约束投影（核心！将点强制拉回[lb,ub]区间）
function x_proj = project2constraint(x, lb, ub)
    x_proj = max(min(x, ub), lb); % 超出上界取ub，低于下界取lb，在区间内保持原值
end