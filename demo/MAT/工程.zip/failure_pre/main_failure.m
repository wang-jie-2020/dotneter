function [F,F_up,annual_F,annual_F_up] = main_failure (normal_time,normal_num,failure_time_low,failure_time_up,failure_num)
    %%参数说明
    %输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量；failure_time_low：失效pack服役时间下限；failure_time_up：失效pack服役时间上限；t：预测年限（如预测10年失效率）
    %输出：F：累积失效率；F_up：累积失效率上限（95%置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失效率上限（95%置信水平）
    %% 数据预处理
    normal_packs = [normal_time,normal_num];
    failure_packs = [failure_time_low,failure_time_up,failure_num];

    %% 构建威布尔分布似然函数（处理区间删失数据）,函数名 weibull_loglikelihood
    %% 参数估计-最大似然估计
    %初始参数猜测[beta,eta]
    initial_params = [2.0,5000];%基于经验的初始值
    %优化选项
    options = optimset('Display','iter','MaxIter',1000,'TolX',1e-8,'TolFun',1e-8);
    %约束优化：参数必须为正数
    lb = [0.1,1];%下界
    ub = [10,10000000];%上界
    %最大似然函数（最小化负似然？）
    negloglik = @(params)-weibull_loglikelihood(params, normal_packs, failure_packs);
    [estimated_params, exitflag] = myfmincon(negloglik,initial_params,[],[],[],[],lb,ub,[],options);
    if exitflag>0
        beta_hat = estimated_params(1);
        eta_hat = estimated_params(2);
       % logL_value = -neg_logL;
    else
        error('参数估计失败，请检查数据或初始值');
    end

    %% 年度失效率预测
    years = 1:20; %year为预测年限，一般为20年
    annual_F = zeros(size(years));
    F = zeros(size(years));%累积失效概率
    F_up = zeros(size(years));
    annual_F_up =  zeros(size(years));

    for i = 1:length(years)
        t_months = years(i)*12;%转换为月份
        F(i) = 1-exp(-(t_months/eta_hat)^beta_hat);%累积失效率
        F_1 = profile_likelihood(t_months,normal_packs, failure_packs);%累积失效率置信区间
        F_up(i) = F_1(2);

        if i == 1
            annual_F(i) = F(i);
            annual_F_up = F_up(i);
        else
            annual_F(i) = F(i)-F((i-1));
            annual_F_up(i) = F_up(i)-F_up((i-1));
        end
    end

end






    





