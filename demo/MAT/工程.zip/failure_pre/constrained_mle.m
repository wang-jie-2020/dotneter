function [beta_opt, eta_opt, loglik_opt] = constrained_mle(F0, t, normal_data, failure_data, beta_start, eta_start)
    % 在约束 F(t) = F0 下的最大似然估计
    % 从约束 F(t) = F0 解出一个参数
    % F0 = 1 - exp(-(t/eta)^beta)
    % => (t/eta)^beta = -log(1-F0)
    % => eta = t / (-log(1-F0))^(1/beta)
    
    % 我们选择优化β，然后根据约束计算η
    neg_loglik_constrained = @(beta) constrained_neg_loglik(beta, F0, t, normal_data, failure_data);
    
    % 优化范围
    beta_lb = 0.1;
    beta_ub = 10;
    
    try
        beta_opt = fminbnd(neg_loglik_constrained, beta_lb, beta_ub);
        eta_opt = t / (-log(1-F0))^(1/beta_opt);
        loglik_opt = -neg_loglik_constrained(beta_opt);
    catch
        % 如果优化失败，使用合理的默认值
        beta_opt = beta_start;
        eta_opt = eta_start;
        loglik_opt = -1e10;  % 惩罚值
    end
end