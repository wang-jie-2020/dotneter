/*
* MATLAB Compiler: 24.1 (R2024a)
* Date: Wed Feb 11 09:52:03 2026
* Arguments:
* "-B""macro_default""-W""dotnet:main_failure,MainFailure,4.0,private,version=1.0""-T""lin
* k:lib""-d""C:\Users\Administrator\Documents\MATLAB\failure_pre\main_failure\for_testing"
* "-v""class{MainFailure:C:\Users\Administrator\Documents\MATLAB\failure_pre\constrained_m
* le.m,C:\Users\Administrator\Documents\MATLAB\failure_pre\constrained_neg_loglik.m,C:\Use
* rs\Administrator\Documents\MATLAB\failure_pre\main_failure.m,C:\Users\Administrator\Docu
* ments\MATLAB\failure_pre\mychi2inv.m,C:\Users\Administrator\Documents\MATLAB\failure_pre
* \myfmincon.m,C:\Users\Administrator\Documents\MATLAB\failure_pre\optimoptions.m,C:\Users
* \Administrator\Documents\MATLAB\failure_pre\profile_likelihood.m,C:\Users\Administrator\
* Documents\MATLAB\failure_pre\unconstrained_mle.m,C:\Users\Administrator\Documents\MATLAB
* \failure_pre\weibull_loglikelihood.m}"
*/
using System;
using System.Reflection;
using System.IO;
using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;

#if SHARED
[assembly: System.Reflection.AssemblyKeyFile(@"")]
#endif

namespace main_failureNative
{

  /// <summary>
  /// The MainFailure class provides a CLS compliant, Object (native) interface to the
  /// MATLAB functions contained in the files:
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\constrained_mle.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\constrained_neg_loglik.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\main_failure.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\mychi2inv.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\myfmincon.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\optimoptions.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\profile_likelihood.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\unconstrained_mle.m
  /// <newpara></newpara>
  /// C:\Users\Administrator\Documents\MATLAB\failure_pre\weibull_loglikelihood.m
  /// </summary>
  /// <remarks>
  /// @Version 1.0
  /// </remarks>
  public class MainFailure : IDisposable
  {
    #region Constructors

    /// <summary internal= "true">
    /// The static constructor instantiates and initializes the MATLAB Runtime instance.
    /// </summary>
    static MainFailure()
    {
      if (MWMCR.MCRAppInitialized)
      {
        try
        {
          System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();

          string ctfFilePath= assembly.Location;

		  int lastDelimiter = ctfFilePath.LastIndexOf(@"/");

	      if (lastDelimiter == -1)
		  {
		    lastDelimiter = ctfFilePath.LastIndexOf(@"\");
		  }

          ctfFilePath= ctfFilePath.Remove(lastDelimiter, (ctfFilePath.Length - lastDelimiter));

          string ctfFileName = "main_failure.ctf";

          Stream embeddedCtfStream = null;

          String[] resourceStrings = assembly.GetManifestResourceNames();

          foreach (String name in resourceStrings)
          {
            if (name.Contains(ctfFileName))
            {
              embeddedCtfStream = assembly.GetManifestResourceStream(name);
              break;
            }
          }
          mcr= new MWMCR("",
                         ctfFilePath, embeddedCtfStream, true);
        }
        catch(Exception ex)
        {
          ex_ = new Exception("MWArray assembly failed to be initialized", ex);
        }
      }
      else
      {
        ex_ = new ApplicationException("MWArray assembly could not be initialized");
      }
    }


    /// <summary>
    /// Constructs a new instance of the MainFailure class.
    /// </summary>
    public MainFailure()
    {
      if(ex_ != null)
      {
        throw ex_;
      }
    }


    #endregion Constructors

    #region Finalize

    /// <summary internal= "true">
    /// Class destructor called by the CLR garbage collector.
    /// </summary>
    ~MainFailure()
    {
      Dispose(false);
    }


    /// <summary>
    /// Frees the native resources associated with this object
    /// </summary>
    public void Dispose()
    {
      Dispose(true);

      GC.SuppressFinalize(this);
    }


    /// <summary internal= "true">
    /// Internal dispose function
    /// </summary>
    protected virtual void Dispose(bool disposing)
    {
      if (!disposed)
      {
        disposed= true;

        if (disposing)
        {
          // Free managed resources;
        }

        // Free native resources
      }
    }


    #endregion Finalize

    #region Methods

    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle()
    {
      return mcr.EvaluateFunction("constrained_mle", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="F0">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle(Object F0)
    {
      return mcr.EvaluateFunction("constrained_mle", F0);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle(Object F0, Object t)
    {
      return mcr.EvaluateFunction("constrained_mle", F0, t);
    }


    /// <summary>
    /// Provides a single output, 3-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle(Object F0, Object t, Object normal_data)
    {
      return mcr.EvaluateFunction("constrained_mle", F0, t, normal_data);
    }


    /// <summary>
    /// Provides a single output, 4-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <param name="failure_data">Input argument #4</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle(Object F0, Object t, Object normal_data, Object 
                            failure_data)
    {
      return mcr.EvaluateFunction("constrained_mle", F0, t, normal_data, failure_data);
    }


    /// <summary>
    /// Provides a single output, 5-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <param name="failure_data">Input argument #4</param>
    /// <param name="beta_start">Input argument #5</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle(Object F0, Object t, Object normal_data, Object 
                            failure_data, Object beta_start)
    {
      return mcr.EvaluateFunction("constrained_mle", F0, t, normal_data, failure_data, beta_start);
    }


    /// <summary>
    /// Provides a single output, 6-input Objectinterface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <param name="failure_data">Input argument #4</param>
    /// <param name="beta_start">Input argument #5</param>
    /// <param name="eta_start">Input argument #6</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_mle(Object F0, Object t, Object normal_data, Object 
                            failure_data, Object beta_start, Object eta_start)
    {
      return mcr.EvaluateFunction("constrained_mle", F0, t, normal_data, failure_data, beta_start, eta_start);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="F0">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut, Object F0)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", F0);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut, Object F0, Object t)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", F0, t);
    }


    /// <summary>
    /// Provides the standard 3-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut, Object F0, Object t, Object 
                              normal_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", F0, t, normal_data);
    }


    /// <summary>
    /// Provides the standard 4-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <param name="failure_data">Input argument #4</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut, Object F0, Object t, Object 
                              normal_data, Object failure_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", F0, t, normal_data, failure_data);
    }


    /// <summary>
    /// Provides the standard 5-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <param name="failure_data">Input argument #4</param>
    /// <param name="beta_start">Input argument #5</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut, Object F0, Object t, Object 
                              normal_data, Object failure_data, Object beta_start)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", F0, t, normal_data, failure_data, beta_start);
    }


    /// <summary>
    /// Provides the standard 6-input Object interface to the constrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="F0">Input argument #1</param>
    /// <param name="t">Input argument #2</param>
    /// <param name="normal_data">Input argument #3</param>
    /// <param name="failure_data">Input argument #4</param>
    /// <param name="beta_start">Input argument #5</param>
    /// <param name="eta_start">Input argument #6</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_mle(int numArgsOut, Object F0, Object t, Object 
                              normal_data, Object failure_data, Object beta_start, Object 
                              eta_start)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_mle", F0, t, normal_data, failure_data, beta_start, eta_start);
    }


    /// <summary>
    /// Provides an interface for the constrained_mle function in which the input and
    /// output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 在约束 F(t) = F0 下的最大似然估计
    /// 从约束 F(t) = F0 解出一个参数
    /// F0 = 1 - exp(-(t/eta)^beta)
    /// => (t/eta)^beta = -log(1-F0)
    /// => eta = t / (-log(1-F0))^(1/beta)
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("constrained_mle", 6, 3, 0)]
    protected void constrained_mle(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("constrained_mle", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_neg_loglik()
    {
      return mcr.EvaluateFunction("constrained_neg_loglik", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="beta">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_neg_loglik(Object beta)
    {
      return mcr.EvaluateFunction("constrained_neg_loglik", beta);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_neg_loglik(Object beta, Object F0)
    {
      return mcr.EvaluateFunction("constrained_neg_loglik", beta, F0);
    }


    /// <summary>
    /// Provides a single output, 3-input Objectinterface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <param name="t">Input argument #3</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_neg_loglik(Object beta, Object F0, Object t)
    {
      return mcr.EvaluateFunction("constrained_neg_loglik", beta, F0, t);
    }


    /// <summary>
    /// Provides a single output, 4-input Objectinterface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <param name="t">Input argument #3</param>
    /// <param name="normal_data">Input argument #4</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_neg_loglik(Object beta, Object F0, Object t, Object 
                                   normal_data)
    {
      return mcr.EvaluateFunction("constrained_neg_loglik", beta, F0, t, normal_data);
    }


    /// <summary>
    /// Provides a single output, 5-input Objectinterface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <param name="t">Input argument #3</param>
    /// <param name="normal_data">Input argument #4</param>
    /// <param name="failure_data">Input argument #5</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object constrained_neg_loglik(Object beta, Object F0, Object t, Object 
                                   normal_data, Object failure_data)
    {
      return mcr.EvaluateFunction("constrained_neg_loglik", beta, F0, t, normal_data, failure_data);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_neg_loglik(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_neg_loglik", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="beta">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_neg_loglik(int numArgsOut, Object beta)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_neg_loglik", beta);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_neg_loglik(int numArgsOut, Object beta, Object F0)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_neg_loglik", beta, F0);
    }


    /// <summary>
    /// Provides the standard 3-input Object interface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <param name="t">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_neg_loglik(int numArgsOut, Object beta, Object F0, Object 
                                     t)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_neg_loglik", beta, F0, t);
    }


    /// <summary>
    /// Provides the standard 4-input Object interface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <param name="t">Input argument #3</param>
    /// <param name="normal_data">Input argument #4</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_neg_loglik(int numArgsOut, Object beta, Object F0, Object 
                                     t, Object normal_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_neg_loglik", beta, F0, t, normal_data);
    }


    /// <summary>
    /// Provides the standard 5-input Object interface to the constrained_neg_loglik
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="beta">Input argument #1</param>
    /// <param name="F0">Input argument #2</param>
    /// <param name="t">Input argument #3</param>
    /// <param name="normal_data">Input argument #4</param>
    /// <param name="failure_data">Input argument #5</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] constrained_neg_loglik(int numArgsOut, Object beta, Object F0, Object 
                                     t, Object normal_data, Object failure_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "constrained_neg_loglik", beta, F0, t, normal_data, failure_data);
    }


    /// <summary>
    /// Provides an interface for the constrained_neg_loglik function in which the input
    /// and output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 约束下的负对数似然函数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("constrained_neg_loglik", 5, 1, 0)]
    protected void constrained_neg_loglik(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("constrained_neg_loglik", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object main_failure()
    {
      return mcr.EvaluateFunction("main_failure", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="normal_time">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object main_failure(Object normal_time)
    {
      return mcr.EvaluateFunction("main_failure", normal_time);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object main_failure(Object normal_time, Object normal_num)
    {
      return mcr.EvaluateFunction("main_failure", normal_time, normal_num);
    }


    /// <summary>
    /// Provides a single output, 3-input Objectinterface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <param name="failure_time_low">Input argument #3</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object main_failure(Object normal_time, Object normal_num, Object 
                         failure_time_low)
    {
      return mcr.EvaluateFunction("main_failure", normal_time, normal_num, failure_time_low);
    }


    /// <summary>
    /// Provides a single output, 4-input Objectinterface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <param name="failure_time_low">Input argument #3</param>
    /// <param name="failure_time_up">Input argument #4</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object main_failure(Object normal_time, Object normal_num, Object 
                         failure_time_low, Object failure_time_up)
    {
      return mcr.EvaluateFunction("main_failure", normal_time, normal_num, failure_time_low, failure_time_up);
    }


    /// <summary>
    /// Provides a single output, 5-input Objectinterface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <param name="failure_time_low">Input argument #3</param>
    /// <param name="failure_time_up">Input argument #4</param>
    /// <param name="failure_num">Input argument #5</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object main_failure(Object normal_time, Object normal_num, Object 
                         failure_time_low, Object failure_time_up, Object failure_num)
    {
      return mcr.EvaluateFunction("main_failure", normal_time, normal_num, failure_time_low, failure_time_up, failure_num);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] main_failure(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "main_failure", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_time">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] main_failure(int numArgsOut, Object normal_time)
    {
      return mcr.EvaluateFunction(numArgsOut, "main_failure", normal_time);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] main_failure(int numArgsOut, Object normal_time, Object normal_num)
    {
      return mcr.EvaluateFunction(numArgsOut, "main_failure", normal_time, normal_num);
    }


    /// <summary>
    /// Provides the standard 3-input Object interface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <param name="failure_time_low">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] main_failure(int numArgsOut, Object normal_time, Object normal_num, 
                           Object failure_time_low)
    {
      return mcr.EvaluateFunction(numArgsOut, "main_failure", normal_time, normal_num, failure_time_low);
    }


    /// <summary>
    /// Provides the standard 4-input Object interface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <param name="failure_time_low">Input argument #3</param>
    /// <param name="failure_time_up">Input argument #4</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] main_failure(int numArgsOut, Object normal_time, Object normal_num, 
                           Object failure_time_low, Object failure_time_up)
    {
      return mcr.EvaluateFunction(numArgsOut, "main_failure", normal_time, normal_num, failure_time_low, failure_time_up);
    }


    /// <summary>
    /// Provides the standard 5-input Object interface to the main_failure MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_time">Input argument #1</param>
    /// <param name="normal_num">Input argument #2</param>
    /// <param name="failure_time_low">Input argument #3</param>
    /// <param name="failure_time_up">Input argument #4</param>
    /// <param name="failure_num">Input argument #5</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] main_failure(int numArgsOut, Object normal_time, Object normal_num, 
                           Object failure_time_low, Object failure_time_up, Object 
                           failure_num)
    {
      return mcr.EvaluateFunction(numArgsOut, "main_failure", normal_time, normal_num, failure_time_low, failure_time_up, failure_num);
    }


    /// <summary>
    /// Provides an interface for the main_failure function in which the input and output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 参数说明
    /// 输入：normal_time:正常pack运行时间；normal_num：正常pack出货数量�
    /// ��failure_time_low：失效pack服役时间下限；failure_time_up：失效pack�
    /// �役时间上限；t：预测年限（如预测10年失效率）
    /// 输出：F：累积失效率；F_up：累积失效率上限（95 
    /// 置信水平）；annual_F：每年年度失效率；annual_F_up：每年年度失
    /// 效率上限（95  置信水平）
    /// 数据预处理
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("main_failure", 5, 4, 0)]
    protected void main_failure(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("main_failure", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the mychi2inv MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object mychi2inv()
    {
      return mcr.EvaluateFunction("mychi2inv", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the mychi2inv MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <param name="p">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object mychi2inv(Object p)
    {
      return mcr.EvaluateFunction("mychi2inv", p);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the mychi2inv MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <param name="p">Input argument #1</param>
    /// <param name="df">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object mychi2inv(Object p, Object df)
    {
      return mcr.EvaluateFunction("mychi2inv", p, df);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the mychi2inv MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] mychi2inv(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "mychi2inv", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the mychi2inv MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="p">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] mychi2inv(int numArgsOut, Object p)
    {
      return mcr.EvaluateFunction(numArgsOut, "mychi2inv", p);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the mychi2inv MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="p">Input argument #1</param>
    /// <param name="df">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] mychi2inv(int numArgsOut, Object p, Object df)
    {
      return mcr.EvaluateFunction(numArgsOut, "mychi2inv", p, df);
    }


    /// <summary>
    /// Provides an interface for the mychi2inv function in which the input and output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 自定义卡方分布逆累积分布函数，替代MATLAB
    /// chi2inv（无Statistics工具箱依赖）
    /// 输入：
    /// p - 累积概率，0 &lt; p &lt; 1（如0.95对应95  置信水平）
    /// df - 卡方分布自由度，正整数（原代码中df=1）
    /// 输出：
    /// x - 临界值，满足P(χ²(df) ≤ x) = p
    /// 核心：卡方CDF（基于下不完全伽马函数） +
    /// 二分法求逆，纯基础代码实现
    /// 适配原代码：mychi2inv(0.95,1) =
    /// 3.8415（与原chi2inv结果一致，精度1e-8）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("mychi2inv", 2, 1, 0)]
    protected void mychi2inv(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("mychi2inv", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon()
    {
      return mcr.EvaluateFunction("myfmincon", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0);
    }


    /// <summary>
    /// Provides a single output, 3-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A);
    }


    /// <summary>
    /// Provides a single output, 4-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b);
    }


    /// <summary>
    /// Provides a single output, 5-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b, Object Aeq)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b, Aeq);
    }


    /// <summary>
    /// Provides a single output, 6-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b, Object Aeq, 
                      Object beq)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b, Aeq, beq);
    }


    /// <summary>
    /// Provides a single output, 7-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b, Object Aeq, 
                      Object beq, Object lb)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b, Aeq, beq, lb);
    }


    /// <summary>
    /// Provides a single output, 8-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <param name="ub">Input argument #8</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b, Object Aeq, 
                      Object beq, Object lb, Object ub)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b, Aeq, beq, lb, ub);
    }


    /// <summary>
    /// Provides a single output, 9-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <param name="ub">Input argument #8</param>
    /// <param name="nonlcon">Input argument #9</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b, Object Aeq, 
                      Object beq, Object lb, Object ub, Object nonlcon)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b, Aeq, beq, lb, ub, nonlcon);
    }


    /// <summary>
    /// Provides a single output, 10-input Objectinterface to the myfmincon MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <param name="ub">Input argument #8</param>
    /// <param name="nonlcon">Input argument #9</param>
    /// <param name="options">Input argument #10</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object myfmincon(Object obj_fun, Object x0, Object A, Object b, Object Aeq, 
                      Object beq, Object lb, Object ub, Object nonlcon, Object options)
    {
      return mcr.EvaluateFunction("myfmincon", obj_fun, x0, A, b, Aeq, beq, lb, ub, nonlcon, options);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0);
    }


    /// <summary>
    /// Provides the standard 3-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A);
    }


    /// <summary>
    /// Provides the standard 4-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b);
    }


    /// <summary>
    /// Provides the standard 5-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b, Object Aeq)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b, Aeq);
    }


    /// <summary>
    /// Provides the standard 6-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b, Object Aeq, Object beq)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b, Aeq, beq);
    }


    /// <summary>
    /// Provides the standard 7-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b, Object Aeq, Object beq, Object lb)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b, Aeq, beq, lb);
    }


    /// <summary>
    /// Provides the standard 8-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <param name="ub">Input argument #8</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b, Object Aeq, Object beq, Object lb, Object ub)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b, Aeq, beq, lb, ub);
    }


    /// <summary>
    /// Provides the standard 9-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <param name="ub">Input argument #8</param>
    /// <param name="nonlcon">Input argument #9</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b, Object Aeq, Object beq, Object lb, Object ub, Object nonlcon)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b, Aeq, beq, lb, ub, nonlcon);
    }


    /// <summary>
    /// Provides the standard 10-input Object interface to the myfmincon MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="obj_fun">Input argument #1</param>
    /// <param name="x0">Input argument #2</param>
    /// <param name="A">Input argument #3</param>
    /// <param name="b">Input argument #4</param>
    /// <param name="Aeq">Input argument #5</param>
    /// <param name="beq">Input argument #6</param>
    /// <param name="lb">Input argument #7</param>
    /// <param name="ub">Input argument #8</param>
    /// <param name="nonlcon">Input argument #9</param>
    /// <param name="options">Input argument #10</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] myfmincon(int numArgsOut, Object obj_fun, Object x0, Object A, Object 
                        b, Object Aeq, Object beq, Object lb, Object ub, Object nonlcon, 
                        Object options)
    {
      return mcr.EvaluateFunction(numArgsOut, "myfmincon", obj_fun, x0, A, b, Aeq, beq, lb, ub, nonlcon, options);
    }


    /// <summary>
    /// Provides an interface for the myfmincon function in which the input and output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 自定义约束优化函数：替代MATLAB
    /// fmincon，适配上下界约束（lb/ub），无等式/不等式约束（A/b/Aeq/b
    /// eq/nonlcon暂置空）
    /// 输入格式与fmincon完全一致，适配原代码调用：[x,fval]=fmincon(fun,
    /// x0,[],[],[],[],lb,ub,[],options)
    /// 核心算法：Nelder-Mead单纯形法 +
    /// 约束投影（超出lb/ub的点强制拉回约束区间）
    /// 适用场景：仅上下界约束的标量目标函数最小化（完美适配原�
    /// ��码负对数似然函数最小化）
    /// 输出：x_opt-最优参数，fval_opt-最优目标函数值，exitflag-收敛标�
    /// ��（1=收敛，0=达到最大迭代，-1=失败）
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("myfmincon", 10, 3, 0)]
    protected void myfmincon(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("myfmincon", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the optimoptions MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object optimoptions()
    {
      return mcr.EvaluateFunction("optimoptions", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the optimoptions MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <param name="optimizer">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object optimoptions(Object optimizer)
    {
      return mcr.EvaluateFunction("optimoptions", optimizer);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the optimoptions MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <param name="optimizer">Input argument #1</param>
    /// <param name="varargin">Array of Objects representing the input arguments 2
    /// through varargin.length+1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object optimoptions(Object optimizer, params Object[] varargin)
    {
      Object[] argsIn= {optimizer, varargin};

      return mcr.EvaluateFunction("optimoptions", argsIn);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the optimoptions MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] optimoptions(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "optimoptions", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the optimoptions MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="optimizer">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] optimoptions(int numArgsOut, Object optimizer)
    {
      return mcr.EvaluateFunction(numArgsOut, "optimoptions", optimizer);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the optimoptions MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="optimizer">Input argument #1</param>
    /// <param name="varargin">Array of Objects representing the input arguments 2
    /// through varargin.length+1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] optimoptions(int numArgsOut, Object optimizer, params Object[] 
                           varargin)
    {
      Object[] argsIn= {optimizer, varargin};

      return mcr.EvaluateFunction(numArgsOut, "optimoptions", argsIn);
    }


    /// <summary>
    /// Provides an interface for the optimoptions function in which the input and output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 自定义优化选项配置函数，替代MATLAB
    /// optimoptions（无Optimization工具箱依赖）
    /// 调用格式与原函数完全一致，适配所有常见优化选项：
    /// 示例1：optimoptions('fmincon', 'Display', 'off', 'Algorithm',
    /// 'interior-point')
    /// 示例2：optimoptions('fmincon', 'Display', 'iter', 'MaxIter', 1000, 'TolX',
    /// 1e-8)
    /// 输入：
    /// optimizer -
    /// 优化器名称（字符型，如'fmincon'/'fminsearch'，仅做兼容，无实际
    /// 限制）
    /// varargin  -
    /// 可变参数，必须为「选项名-选项值」成对的字符+值组合
    /// 输出：
    /// options   -
    /// 优化选项结构体，字段为选项名（如Display/MaxIter），值为对应�
    /// ��置
    /// 特性：兼容原函数所有选项，无工具箱依赖，与自定义myfmincon�
    /// ��美适配
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("optimoptions", 1, 1, 1)]
    protected void optimoptions(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("optimoptions", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the profile_likelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object profile_likelihood()
    {
      return mcr.EvaluateFunction("profile_likelihood", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the profile_likelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="t">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object profile_likelihood(Object t)
    {
      return mcr.EvaluateFunction("profile_likelihood", t);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the profile_likelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object profile_likelihood(Object t, Object normal_data)
    {
      return mcr.EvaluateFunction("profile_likelihood", t, normal_data);
    }


    /// <summary>
    /// Provides a single output, 3-input Objectinterface to the profile_likelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object profile_likelihood(Object t, Object normal_data, Object failure_data)
    {
      return mcr.EvaluateFunction("profile_likelihood", t, normal_data, failure_data);
    }


    /// <summary>
    /// Provides a single output, 4-input Objectinterface to the profile_likelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <param name="alpha">Input argument #4</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object profile_likelihood(Object t, Object normal_data, Object failure_data, 
                               Object alpha)
    {
      return mcr.EvaluateFunction("profile_likelihood", t, normal_data, failure_data, alpha);
    }


    /// <summary>
    /// Provides a single output, 5-input Objectinterface to the profile_likelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <param name="alpha">Input argument #4</param>
    /// <param name="F_range">Input argument #5</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object profile_likelihood(Object t, Object normal_data, Object failure_data, 
                               Object alpha, Object F_range)
    {
      return mcr.EvaluateFunction("profile_likelihood", t, normal_data, failure_data, alpha, F_range);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the profile_likelihood MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] profile_likelihood(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "profile_likelihood", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the profile_likelihood MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="t">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] profile_likelihood(int numArgsOut, Object t)
    {
      return mcr.EvaluateFunction(numArgsOut, "profile_likelihood", t);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the profile_likelihood MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] profile_likelihood(int numArgsOut, Object t, Object normal_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "profile_likelihood", t, normal_data);
    }


    /// <summary>
    /// Provides the standard 3-input Object interface to the profile_likelihood MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] profile_likelihood(int numArgsOut, Object t, Object normal_data, 
                                 Object failure_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "profile_likelihood", t, normal_data, failure_data);
    }


    /// <summary>
    /// Provides the standard 4-input Object interface to the profile_likelihood MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <param name="alpha">Input argument #4</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] profile_likelihood(int numArgsOut, Object t, Object normal_data, 
                                 Object failure_data, Object alpha)
    {
      return mcr.EvaluateFunction(numArgsOut, "profile_likelihood", t, normal_data, failure_data, alpha);
    }


    /// <summary>
    /// Provides the standard 5-input Object interface to the profile_likelihood MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="t">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <param name="alpha">Input argument #4</param>
    /// <param name="F_range">Input argument #5</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] profile_likelihood(int numArgsOut, Object t, Object normal_data, 
                                 Object failure_data, Object alpha, Object F_range)
    {
      return mcr.EvaluateFunction(numArgsOut, "profile_likelihood", t, normal_data, failure_data, alpha, F_range);
    }


    /// <summary>
    /// Provides an interface for the profile_likelihood function in which the input and
    /// output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 使用Profile似然法计算累积失效率F(t)的置信区间
    /// 输入:
    /// t - 时间点
    /// data - 包含lower_bounds, upper_bounds, censoring_codes的数据
    /// alpha - 显著性水平 (默认0.05)
    /// F_range - F值的搜索范围 (可选)
    /// 输出:
    /// F_CI - 置信区间 [下限, 上限]
    /// F_profile - 用于绘图的F值数组
    /// LR_stat - 似然比统计量数组
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("profile_likelihood", 5, 1, 0)]
    protected void profile_likelihood(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("profile_likelihood", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the unconstrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object unconstrained_mle()
    {
      return mcr.EvaluateFunction("unconstrained_mle", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the unconstrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <param name="normal_data">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object unconstrained_mle(Object normal_data)
    {
      return mcr.EvaluateFunction("unconstrained_mle", normal_data);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the unconstrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <param name="normal_data">Input argument #1</param>
    /// <param name="failure_data">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object unconstrained_mle(Object normal_data, Object failure_data)
    {
      return mcr.EvaluateFunction("unconstrained_mle", normal_data, failure_data);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the unconstrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] unconstrained_mle(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "unconstrained_mle", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the unconstrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_data">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] unconstrained_mle(int numArgsOut, Object normal_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "unconstrained_mle", normal_data);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the unconstrained_mle MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="normal_data">Input argument #1</param>
    /// <param name="failure_data">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] unconstrained_mle(int numArgsOut, Object normal_data, Object 
                                failure_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "unconstrained_mle", normal_data, failure_data);
    }


    /// <summary>
    /// Provides an interface for the unconstrained_mle function in which the input and
    /// output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 无约束威布尔分布参数最大似然估计
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("unconstrained_mle", 2, 3, 0)]
    protected void unconstrained_mle(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("unconstrained_mle", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }
    /// <summary>
    /// Provides a single output, 0-input Objectinterface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object weibull_loglikelihood()
    {
      return mcr.EvaluateFunction("weibull_loglikelihood", new Object[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input Objectinterface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="params0">Input argument #1</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object weibull_loglikelihood(Object params0)
    {
      return mcr.EvaluateFunction("weibull_loglikelihood", params0);
    }


    /// <summary>
    /// Provides a single output, 2-input Objectinterface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="params0">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object weibull_loglikelihood(Object params0, Object normal_data)
    {
      return mcr.EvaluateFunction("weibull_loglikelihood", params0, normal_data);
    }


    /// <summary>
    /// Provides a single output, 3-input Objectinterface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="params0">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <returns>An Object containing the first output argument.</returns>
    ///
    public Object weibull_loglikelihood(Object params0, Object normal_data, Object 
                                  failure_data)
    {
      return mcr.EvaluateFunction("weibull_loglikelihood", params0, normal_data, failure_data);
    }


    /// <summary>
    /// Provides the standard 0-input Object interface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] weibull_loglikelihood(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "weibull_loglikelihood", new Object[]{});
    }


    /// <summary>
    /// Provides the standard 1-input Object interface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="params0">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] weibull_loglikelihood(int numArgsOut, Object params0)
    {
      return mcr.EvaluateFunction(numArgsOut, "weibull_loglikelihood", params0);
    }


    /// <summary>
    /// Provides the standard 2-input Object interface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="params0">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] weibull_loglikelihood(int numArgsOut, Object params0, Object 
                                    normal_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "weibull_loglikelihood", params0, normal_data);
    }


    /// <summary>
    /// Provides the standard 3-input Object interface to the weibull_loglikelihood
    /// MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="params0">Input argument #1</param>
    /// <param name="normal_data">Input argument #2</param>
    /// <param name="failure_data">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public Object[] weibull_loglikelihood(int numArgsOut, Object params0, Object 
                                    normal_data, Object failure_data)
    {
      return mcr.EvaluateFunction(numArgsOut, "weibull_loglikelihood", params0, normal_data, failure_data);
    }


    /// <summary>
    /// Provides an interface for the weibull_loglikelihood function in which the input
    /// and output
    /// arguments are specified as an array of Objects.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// 构建威布尔分布似然函数（处理区间删失数据）
    /// parrms = [beta,eta]形状参数和尺度参数
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of Object output arguments</param>
    /// <param name= "argsIn">Array of Object input arguments</param>
    /// <param name= "varArgsIn">Array of Object representing variable input
    /// arguments</param>
    ///
    [MATLABSignature("weibull_loglikelihood", 3, 1, 0)]
    protected void weibull_loglikelihood(int numArgsOut, ref Object[] argsOut, Object[] argsIn, params Object[] varArgsIn)
    {
        mcr.EvaluateFunctionForTypeSafeCall("weibull_loglikelihood", numArgsOut, ref argsOut, argsIn, varArgsIn);
    }

    /// <summary>
    /// This method will cause a MATLAB figure window to behave as a modal dialog box.
    /// The method will not return until all the figure windows associated with this
    /// component have been closed.
    /// </summary>
    /// <remarks>
    /// An application should only call this method when required to keep the
    /// MATLAB figure window from disappearing.  Other techniques, such as calling
    /// Console.ReadLine() from the application should be considered where
    /// possible.</remarks>
    ///
    public void WaitForFiguresToDie()
    {
      mcr.WaitForFiguresToDie();
    }



    #endregion Methods

    #region Class Members

    private static MWMCR mcr= null;

    private static Exception ex_= null;

    private bool disposed= false;

    #endregion Class Members
  }
}
