
using System;
using System.Reflection;

// Set version number for the assembly.
#if __IN_MCC
[assembly: AssemblyVersionAttribute("1.0.0.0")]
#endif
