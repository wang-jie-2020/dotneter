﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var i1 = SdkWorker.checkOutRecordPermission1();
            var i2 = SdkWorker.checkOutRecordPermission2();
            var i3 = SdkWorker.checkOutRecordPermission3();



            Console.WriteLine("Hello, World!");
        }
    }
}