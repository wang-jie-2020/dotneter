﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public static class SdkWorker
    {
        [DllImport("ac_buf_come.dll", EntryPoint = "checkOutRecordPermission")]
        public static extern int checkOutRecordPermission1();

        [DllImport("IflyRecordDll.dll", EntryPoint = "checkOutRecordPermission")]
        public static extern int checkOutRecordPermission2();

        [DllImport("mix_record_lib.dll", EntryPoint = "checkOutRecordPermission")]
        public static extern int checkOutRecordPermission3();

    }
}
